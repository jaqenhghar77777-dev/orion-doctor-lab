Fictional local identity 7293.
